let Obj;// This Obj variable should have the interface that you will create

export default Obj;// Make no changes here